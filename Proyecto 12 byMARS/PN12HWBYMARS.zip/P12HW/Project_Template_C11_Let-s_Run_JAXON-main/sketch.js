var pista, pistaImage, nn, nnAnimation;

function preload(){
  //pre-load images
pistaImage=loadImage ("path.png");
nnAnimation= loadAnimation ("r1.png","r2.png");
}

function setup(){
  createCanvas(400,400);
  //Only functions Sprites, functions are in the line number 30
  Pista();
 Nn(); 

}

function draw() {
  background(0);
drawSprites ();
edges=createEdgeSprites();
resetPista();
nnV();
nn.collide(edges);
}





//Creacion de la pista
function Pista (){
  pista=createSprite (200,200,20,20);
pista.velocityY= 4;
pista.addImage (pistaImage);
pista.scale=1.2;
}
//reseteo de la pista
function resetPista (){
if (pista.y > 400){
  pista.y = height/4;
}
}
//Creacion de nn
function Nn (){
  nn=createSprite (200,300,15,15);
 nn.addAnimation ("ninocorriendo",nnAnimation);
 nn.scale=0.05;
}
//Velocidad de nn
function nnV (){
  nn.x=World.mouseX;
}