//creacion de variables

var sea,seaImage, ship, shipAnimation;

function preload(){
//Carga de Imagenes y/o Animaciones
  shipAnimation= loadAnimation ("ship-1.png","ship-3.png","ship-2.png","ship-1.png");
seaImage= loadImage ("sea.png")
}

function setup(){
  createCanvas(400,400);
//Mar
  spawnSea();

//Barco
spawnBarco();
}

function draw() {
  background("blue");
  //Reseteo del Mar
  resetSea();  
 drawSprites();
}





//Funciones para una creacion mas compacta de los Sprites (spawnSea y spawnBarco), y para el reseteo del mar (resetSea).

function spawnSea(){
//creacion del mar
sea=createSprite (200,200,100);
sea.addImage ("mar",seaImage);
sea.scale=.24;
sea.velocityX=-2;
}


function spawnBarco(){
  //creacion del barco con animacion
ship=createSprite (200,180,50,30);
ship.addAnimation ("movimiento",shipAnimation);
ship.scale= .25;
}


function resetSea(){
  if (sea.x<0){
sea.x = sea.width/9;
  }
}